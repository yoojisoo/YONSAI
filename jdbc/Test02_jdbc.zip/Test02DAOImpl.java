package kr.co.job.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Test02DAOImpl implements Test02DAO {
	
	static Test02DbConn dbConn = new Test02DbConn(); //server connected!
	static Scanner scan = new Scanner(System.in);
	
	public int veiwMenu() {

		System.out.println("======================== [ M E N U ] ========================");
		System.out.println("1.veiw All  2.view One  3.insert  4.update  5.delete  6.close");
		System.out.print("Select Number : ");
		return scan.nextInt();
	}

	private void makeList(ResultSet rs) {
		try {
			dbConn.list = new ArrayList<Test02VO>();
			
			while(dbConn.rs.next()) {
				int tno = dbConn.rs.getInt(1);
				String pname = dbConn.rs.getString(2);
				int age = dbConn.rs.getInt(3);
				String etc = dbConn.rs.getString(4);
				
				dbConn.list.add(new Test02VO(tno, pname, age, etc));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}//makeList()
	
	
	@Override
	public int selectAll() {
		try {
			String sql = "select * from test01";
			dbConn.stmt = dbConn.conn.createStatement();
			dbConn.rs = dbConn.stmt.executeQuery(sql);
			
			if(dbConn.rs.next()) {
				makeList(dbConn.rs);
				
				for(Test02VO result : dbConn.list){
					System.out.println(result.toString());
				}				
			}
			else {
				System.out.println("Sorry:( Not Found Data");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	} //selectAll()

	@Override
	public int selectOne() {
		try {
			System.out.println("=== [ Find by tno ] ===");
			System.out.println("tno : ");
			int pnoNumber = scan.nextInt();
			String sql = "select * from test01 WHERE tno=?";

			dbConn.pstmt = dbConn.conn.prepareStatement(sql);
			dbConn.pstmt.setInt(1, pnoNumber);
			dbConn.rs = dbConn.pstmt.executeQuery();

			if (dbConn.rs.next()) {
				makeList(dbConn.rs);

				for (Test02VO result : dbConn.list) {
					System.out.println(result.toString());
				}
			}
			else {
				System.out.println("Sorry:( Not Found Data");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return 0;
	} //selectOne()
	
	@Override
	public int insert() {
		try {
			System.out.println("===== [ Insert Value ] =====");
			System.out.print("name : ");
			String pname = scan.next();
			System.out.print("age : ");
			int age = scan.nextInt();
			System.out.print("etc : ");
			String etc = scan.next();
			
			String sql = "INSERT INTO test01 (pname, age, etc) VALUES (?, ?, ?)";
			dbConn.pstmt = dbConn.conn.prepareStatement(sql);
			dbConn.pstmt.setString(1, pname);
			dbConn.pstmt.setInt(2, age);
			dbConn.pstmt.setString(3, etc);
			dbConn.result = dbConn.pstmt.executeUpdate(); //fail==0
			
			if(dbConn.result == 0) {
				System.out.println("Sorry, Insertion Failed :(");
			}
			else {
				System.out.println("*~Insert Successful~*");
				
				String sql2 = "SELECT * FROM test01 ORDER BY tno DESC LIMIT 1"; //last insert select
				dbConn.stmt = dbConn.conn.createStatement();
				dbConn.rs = dbConn.stmt.executeQuery(sql2);
				makeList(dbConn.rs);
				System.out.println("Inserted Now : "+dbConn.list.toString());
			}

		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	} //insert()
	
	@Override
	public int update() {
		System.out.println("=== [ Update to tno ] ===");
		System.out.print("tno : ");
		int tno = scan.nextInt();
		System.out.print("name : ");
		String pname = scan.next();
		System.out.print("age : ");
		int age = scan.nextInt();
		System.out.print("etc : ");
		String etc = scan.next();
		
		String sql = "UPDATE test01 SET pname=?, age=?, etc=? WHERE tno=?";

		

		return 0;
	}//update()
	
	@Override
	public int delete() {
		
		return 0;
	}//delete()
	

}
