package kr.co.job.jdbc;

public interface Test02DAO {
	
		public int selectAll();
		
		public int selectOne();
		
		public int insert();

		public int update();
		
		public int delete();
		
}
